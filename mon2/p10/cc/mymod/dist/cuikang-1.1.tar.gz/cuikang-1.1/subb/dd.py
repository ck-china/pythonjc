def dd():
    print('d')
