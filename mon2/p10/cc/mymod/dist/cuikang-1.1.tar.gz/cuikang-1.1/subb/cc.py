def cc():
    print('c')
