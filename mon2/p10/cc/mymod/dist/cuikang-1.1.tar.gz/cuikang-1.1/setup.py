from distutils.core import setup
setup(name="cuikang", version="1.1", description="cuikang's module", author="cuikang", py_modules=['suba.aa', 'suba.bb', 'subb.cc', 'subb.dd'])
