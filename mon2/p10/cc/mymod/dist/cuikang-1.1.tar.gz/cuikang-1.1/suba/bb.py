def bb():
    print('b')
