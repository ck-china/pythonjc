def aa():
    print('a')
